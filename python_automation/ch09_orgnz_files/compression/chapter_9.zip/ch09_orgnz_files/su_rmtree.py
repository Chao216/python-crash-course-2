import shutil as su

su.rmtree("./Back_Up")
