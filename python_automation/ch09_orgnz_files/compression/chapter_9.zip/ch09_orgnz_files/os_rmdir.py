import os

os.rmdir("./folder3")
