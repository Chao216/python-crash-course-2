#! /usr/bin/env python3

import pyperclip as pc

text = str(pc.paste())

print(f"\n{text}")
