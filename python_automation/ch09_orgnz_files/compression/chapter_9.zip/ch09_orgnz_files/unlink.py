import os

os.unlink("./bin/bag/box/toDelete.txt")
