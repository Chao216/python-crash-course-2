import shutil as su

su.move("./folder3/toBeMoved.txt","./folder2/rename_with_move.txt")
