import send2trash as s2t

s2t.send2trash("./delete_with_s2t.txt")
